/*
 * Name:
 * WSUID:
 * Final Exam
 * Implement Book and Shelf classes
 */

#include "Book.hpp"
#include "Genre.hpp"

// Remaining includes below this line


// Implement Book class functions below this line
