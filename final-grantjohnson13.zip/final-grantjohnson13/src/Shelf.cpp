/*
 * Name:
 * WSUID:
 * Final Exam
 * Implement Book and Shelf classes
 */

#include "Shelf.hpp"
#include "Book.hpp"
#include "Genre.hpp"

// Remaining includes below this line


// Implement Shelf class functions below this line


// Implement free function below this line
